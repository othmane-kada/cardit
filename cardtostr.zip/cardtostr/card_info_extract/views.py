from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from PIL import Image
from django.http import HttpResponse
import numpy as np
import urllib.request as ur
import json
import cv2
import os

import pytesseract
from pytesseract import image_to_string
# define the path to the face detector


@csrf_exempt
def detect(request):
    data = {"success": False}
    # check to see if this is a post request
    if request.method == "POST":
        # check to see if an image was uploaded
        if request.FILES.get("image", None) is not None:
            # grab the uploaded image
            image = _grab_image(stream=request.FILES["image"])

        # otherwise, assume that a URL was passed in
        else:
            # grab the URL from the request
            url = request.POST.get("url", None)

            # if the URL is None, then return an error
            if url is None:
                data["error"] = "No URL provided."
                return JsonResponse(data)

            # load the image and convert
            image = _grab_image(url=url)

        fields = ['ID Number', 'رقم الهوية', 'Name',
                  'الإسم', 'Nationality', 'الجنسية']
        data = get_string(image, fields)
        # update the data dictionary with the faces detected
        data.update({"success": True})

    # return a JSON response
    return JsonResponse(data,safe=False,json_dumps_params={'ensure_ascii':False})


def _grab_image(path=None, stream=None, url=None):
    # if the path is not None, then load the image from disk
    if path is not None:
        image = cv2.imread(path)

    else:
        # if the URL is not None, then download the image
        if url is not None:
            resp = ur.urlopen(url)
            data = resp.read()

        # if the stream is not None, then the image has been uploaded
        elif stream is not None:
            data = stream.read()

        # convert the image to a NumPy array and then read it into
        # OpenCV format
        image = np.asarray(bytearray(data), dtype="uint8")
        image = cv2.imdecode(image, cv2.IMREAD_COLOR)
    # return the image
    return image


def get_string(img, fields):
    result = {}
    kernel = np.ones((1, 1), np.uint8)
    text = pytesseract.image_to_string(
        img, lang='eng+ara').replace('\u200e', '')
    result = extract(result, text, fields)
    fields = [i for i in fields if result[i] == '']
    if len(fields) > 0:
        text = pytesseract.image_to_string(cv2.cvtColor(
            img, cv2.COLOR_BGR2GRAY), lang='eng+ara').replace('\u200e', '')
        result = extract(result, text, fields)
        fields = [i for i in fields if result[i] == '']
        if len(fields) > 0:
            text = pytesseract.image_to_string(cv2.dilate(
                img, kernel, iterations=1), lang='eng+ara').replace('\u200e', '')
            result = extract(result, text, fields)
            fields = [i for i in fields if result[i] == '']
            if len(fields) > 0:
                text = pytesseract.image_to_string(cv2.erode(cv2.dilate(
                    img, kernel, iterations=1), kernel, iterations=1), lang='eng+ara').replace('\u200e', '')
                result = extract(result, text, fields)
    return result


def extract(out, text, fields):
    for field in fields:
        out[field] = text[text.find(field)+len(field)+2:text.find(field)+len(field)+text[text.find(
            field)+len(field):].find('\n')].replace('\u200f', '') if text.find(field) >= 0 else ''
        out[field] = text[text.find('784'):text.find(
            '784')+18].replace('\u200f', '') if field in ['ID Number', 'رقم الهوية'] else out[field]
    return out
