from django.apps import AppConfig


class CardInfoExtractConfig(AppConfig):
    name = 'card_info_extract'
